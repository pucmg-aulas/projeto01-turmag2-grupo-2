//package sistemarestaurante;

import controller.SistemaRestauranteController;
import view.SistemaRestauranteView;

public class SistemaRestaurante {
    public static void main(String[] args) {
        SistemaRestauranteView view = new SistemaRestauranteView();
        SistemaRestauranteController controller = new SistemaRestauranteController(view);
        controller.iniciar();
    }
}

