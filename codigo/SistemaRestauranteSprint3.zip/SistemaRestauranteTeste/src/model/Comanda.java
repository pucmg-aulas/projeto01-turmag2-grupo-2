package model;

import java.util.ArrayList;

public class Comanda {
    private ArrayList<ItemCardapio> itensComanda;
    private MetodoPagamento metodoPagamento;

    public Comanda() {
        this.itensComanda = new ArrayList<>();
    }

    public void adicionarItem(ItemCardapio item) {
        itensComanda.add(item);
    }

    public boolean removerItem(int id) {
        for (ItemCardapio item : itensComanda) {
            if (item.getId() == id) {
                itensComanda.remove(item);
                return true;
            }
        }
        return false;
    }

    public ItemCardapio obterItem(int id) {
        for (ItemCardapio item : itensComanda) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    public void listarItens() {
        for (ItemCardapio item : itensComanda) {
            System.out.println(item);
        }
    }

    public double calcularTotal() {
        double total = 0;
        for (ItemCardapio item : itensComanda) {
            total += item.getPreco();
        }
        total += total * 0.10; // Inclui a taxa de serviço de 10%
        return total;
    }

    public double calcularDesconto() {
        double total = calcularTotal();
        return metodoPagamento.calcularDesconto(total);
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }
}
