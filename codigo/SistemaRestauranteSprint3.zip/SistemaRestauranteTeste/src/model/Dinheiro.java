package model;

import java.time.LocalDate;

public class Dinheiro implements MetodoPagamento {
    @Override
    public double calcularDesconto(double valor) {
        return 0;
    }

    @Override
    public LocalDate obterDataRecebimento(LocalDate dataAtual) {
        return dataAtual;
    }
}

