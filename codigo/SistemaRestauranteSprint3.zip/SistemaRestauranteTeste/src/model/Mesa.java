package model;

public class Mesa {
    private int idMesa;
    private int capacidade;
    private boolean disponibilidade;
    private Pedido pedido;
    private Comanda comanda;
    
    public Mesa(int idMesa, int capacidade, boolean disponibilidade) {
        this.idMesa = idMesa;
        this.capacidade = capacidade;
        this.disponibilidade = disponibilidade;
        this.comanda = new Comanda();
    }

    public void alocarMesa(Pedido pedido) {
        this.disponibilidade = false;
        this.pedido = pedido;
    }

    public void desalocarMesa() {
        this.disponibilidade = true;
        this.pedido = null;
    }

    public boolean verificarCapacidade(Pedido pedido) {
        return this.capacidade >= pedido.getNumeroDePessoas();
    }

    // Getters e Setters
    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public Comanda getComanda() {
        return comanda;
    }

    public void setComanda(Comanda comanda) {
        this.comanda = comanda;
    }
}
