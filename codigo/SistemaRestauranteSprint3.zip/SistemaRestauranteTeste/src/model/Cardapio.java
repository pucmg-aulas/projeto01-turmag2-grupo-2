package model;

import java.util.ArrayList;

public class Cardapio {
    private ArrayList<ItemCardapio> itensCardapio;

    public Cardapio() {
        this.itensCardapio = new ArrayList<>();
    }

    public void adicionarAoCardapio(ItemCardapio item) {
        itensCardapio.add(item);
    }

    public boolean removerDoCardapio(int id) {
        for (ItemCardapio item : itensCardapio) {
            if (item.getId() == id) {
                itensCardapio.remove(item);
                return true;
            }
        }
        return false;
    }

    public ItemCardapio pedirItem(int id) {
        for (ItemCardapio item : itensCardapio) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    public void listarCardapio() {
        for (ItemCardapio item : itensCardapio) {
            System.out.println(item.getId() + ": " + item.getNome() + " - Preço: " + item.getPreco());
        }
    }
}
