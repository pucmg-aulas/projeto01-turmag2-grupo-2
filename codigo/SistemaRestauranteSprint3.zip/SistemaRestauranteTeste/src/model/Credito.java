package model;

import java.time.LocalDate;

public class Credito implements MetodoPagamento {
    @Override
    public double calcularDesconto(double valor) {
        return valor * 0.031;
    }

    @Override
    public LocalDate obterDataRecebimento(LocalDate dataAtual) {
        return dataAtual.plusDays(30);
    }
}

