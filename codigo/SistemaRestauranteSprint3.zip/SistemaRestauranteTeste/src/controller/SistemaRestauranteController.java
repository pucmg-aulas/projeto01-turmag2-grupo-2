package controller;

import model.*;
import view.SistemaRestauranteView;

import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SistemaRestauranteController {
    private SistemaRestauranteView view;
    private FilaDePedidos fila;
    private FilaDePedidos historico;
    private Mesa[] mesas;
    private Cardapio cardapio;
    private Scanner scanner;
    private Map<LocalDate, Double> ganhosDiarios;
    private static final String CAMINHO_GANHOS = "ganhos.txt";

    public SistemaRestauranteController(SistemaRestauranteView view) {
        this.view = view;
        this.fila = new FilaDePedidos();
        this.historico = new FilaDePedidos();
        this.mesas = new Mesa[10];
        this.cardapio = new Cardapio();
        this.scanner = new Scanner(System.in);
        this.ganhosDiarios = new HashMap<>();
        inicializarGanhos();
        preencherCardapio();
        quantificarMesas();
    }

    private void inicializarGanhos() {
        try {
            carregarGanhos();
        } catch (IOException e) {
            view.mostrarMensagem("Não foi possível carregar os ganhos. Inicializando um novo registro.");
            ganhosDiarios = new HashMap<>();
        }
    }

    private void preencherCardapio() {
        cardapio.adicionarAoCardapio(new ItemCardapio(1, "Moqueca de Tilápia", 50.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(2, "Falafel Assado", 30.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(3, "Salada Primavera com Macarrão Konjac", 40.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(4, "Escondidinho de Frango", 45.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(5, "Strogonoff", 30.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(6, "Caçarola de Carne com Legumes", 50.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(7, "Água", 5.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(8, "Suco", 8.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(9, "Refrigerante", 7.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(10, "Cerveja", 12.0));
        cardapio.adicionarAoCardapio(new ItemCardapio(11, "Taça de Vinho", 18.0));
    }

    private void quantificarMesas() {
        for (int i = 0; i < 10; i++) {
            int capacidade = (i < 4) ? 4 : (i < 8) ? 6 : 8;
            mesas[i] = new Mesa(i + 1, capacidade, true);
        }
    }

    public void iniciar() {
        view.mostrarMensagem("      *Bem Vindo!*      ");
        menu();
    }

    private void menu() {
        int escolha = 0;

        while (escolha != 10) {
            view.mostrarMenu();
            escolha = scanner.nextInt();

            switch (escolha) {
                case 1:
                    verMesas();
                    break;
                case 2:
                    fila.listarPedidos();
                    break;
                case 3:
                    reservar();
                    break;
                case 4:
                    remover();
                    break;
                case 5:
                    atenderPedido();
                    break;
                case 6:
                    liberarMesa();
                    break;
                case 7:
                    historico.listarHistorico();
                    break;
                case 8:
                    menuServicos();
                    break;
                case 9:
                    pesquisarLucroPorData();
                    break;
                case 10:
                    view.mostrarMensagem("Volte sempre!");
                    break;
                default:
                    view.mostrarMensagem("Escolha uma opção de 1 a 10!");
                    break;
            }
        }
    }

    private void verMesas() {
        view.mostrarMensagem("**********Mesas**********");
        for (Mesa mesa : mesas) {
            String disponibilidade = mesa.isDisponibilidade() ? "Disponível" : "Ocupada";
            view.mostrarMensagem("Mesa " + mesa.getIdMesa() + " Capacidade: " + mesa.getCapacidade() + " " + disponibilidade);
            if (!mesa.isDisponibilidade()) {
                view.mostrarMensagem("Ocupada por: " + mesa.getPedido().getCliente().getNome());
            }
        }
        view.mostrarMensagem("*************************");
    }

    private void reservar() {
        view.mostrarMensagem("Nome do cliente:");
        String nome = scanner.next();

        view.mostrarMensagem("Telefone do cliente:");
        String telefone = scanner.next();

        Cliente cliente = new Cliente(nome, telefone);

        view.mostrarMensagem("Número de pessoas:");
        int numeroDePessoas = scanner.nextInt();

        Pedido pedido = new Pedido(cliente, numeroDePessoas, fila.getFilaDeEspera().size());
        fila.adicionarPedidoAFila(pedido);

        view.mostrarMensagem("Reserva realizada com sucesso!");
    }

    private void remover() {
        view.mostrarMensagem("Qual o ID do pedido que deseja cancelar?");
        int id = scanner.nextInt();
        fila.removerPedidoDaFila(id);
    }

    private void atenderPedido() {
        for (Mesa mesa : mesas) {
            if (mesa.isDisponibilidade()) {
                Pedido pedido = fila.consultarProximoCliente(mesa.getCapacidade());
                if (pedido != null) {
                    pedido.associarData();
                    mesa.alocarMesa(pedido);
                    view.mostrarMensagem("O pedido com ID " + pedido.getId() + " foi alocado à mesa " + mesa.getIdMesa());
                    fila.removerPedidoDaFila(pedido.getId());
                    break;
                }
            }
        }
    }

    private void liberarMesa() {
        verMesas();
        view.mostrarMensagem("Qual mesa deseja desocupar?");
        int mesaId = scanner.nextInt();
        Mesa mesa = mesas[mesaId - 1];

        view.mostrarMensagem("Escolha o método de pagamento: (1) Dinheiro (2) Pix (3) Débito (4) Crédito");
        int escolhaPagamento = scanner.nextInt();
        MetodoPagamento metodoPagamento;

        switch (escolhaPagamento) {
            case 1:
                metodoPagamento = new Dinheiro();
                break;
            case 2:
                metodoPagamento = new Pix();
                break;
            case 3:
                metodoPagamento = new Debito();
                break;
            case 4:
                metodoPagamento = new Credito();
                break;
            default:
                view.mostrarMensagem("Método de pagamento inválido. Usando Dinheiro por padrão.");
                metodoPagamento = new Dinheiro();
                break;
        }

        mesa.getComanda().setMetodoPagamento(metodoPagamento);
        double totalAPagar = mesa.getComanda().calcularTotal();
        double valorPorPessoa = totalAPagar / mesa.getPedido().getNumeroDePessoas();
        double desconto = mesa.getComanda().calcularDesconto();
        double lucroRestaurante = totalAPagar - desconto;

        view.mostrarMensagem("Total a Pagar: R$ " + totalAPagar);
        view.mostrarMensagem("Valor por Pessoa: R$ " + valorPorPessoa);
        view.mostrarMensagem("Lucro do Restaurante após desconto: R$ " + lucroRestaurante);

        mesa.getPedido().registrarSaida();
        historico.adicionarPedidoAFila(mesa.getPedido());
        mesa.desalocarMesa();

        view.mostrarMensagem("A mesa " + mesa.getIdMesa() + " foi desocupada!");

        // Atualizar os ganhos do restaurante
        LocalDate dataAtual = LocalDate.now();
        ganhosDiarios.put(dataAtual, ganhosDiarios.getOrDefault(dataAtual, 0.0) + lucroRestaurante);

        // Persistir os ganhos
        try {
            salvarGanhos();
        } catch (IOException e) {
            view.mostrarMensagem("Erro ao salvar os ganhos: " + e.getMessage());
        }
    }

    private void menuServicos() {
        int escolhaMenu = 0;

        while (escolhaMenu != 6) {
            view.mostrarMenuServicos();
            escolhaMenu = scanner.nextInt();

            switch (escolhaMenu) {
                case 1:
                    verMesas();
                    break;
                case 2:
                    cardapio.listarCardapio();
                    break;
                case 3:
                    fazerPedido();
                    break;
                case 4:
                    cancelarPedido();
                    break;
                case 5:
                    verComanda();
                    break;
                case 6:
                    view.mostrarMensagem("Retornando ao menu principal...");
                    break;
                default:
                    view.mostrarMensagem("Escolha uma opção de 1 a 6!");
                    break;
            }
        }
    }

    private void fazerPedido() {
        verMesas();
        view.mostrarMensagem("Qual mesa fará o pedido?");
        int mesaId = scanner.nextInt() - 1;
        Mesa mesa = mesas[mesaId];

        while (true) {
            cardapio.listarCardapio();
            view.mostrarMensagem("Digite o número do prato ou bebida que deseja ('0' PARA SAIR):");
            int itemId = scanner.nextInt();

            if (itemId == 0) {
                break;
            }

            ItemCardapio item = cardapio.pedirItem(itemId);
            if (item != null) {
                mesa.getComanda().adicionarItem(item);
            } else {
                view.mostrarMensagem("Item não encontrado!");
            }
        }
    }

    private void cancelarPedido() {
        verMesas();
        view.mostrarMensagem("Qual mesa quer cancelar?");
        int mesaId = scanner.nextInt() - 1;
        Mesa mesa = mesas[mesaId];

        mesa.getComanda().listarItens();
        view.mostrarMensagem("Digite o número do prato ou bebida que deseja cancelar:");
        int itemId = scanner.nextInt();
        mesa.getComanda().removerItem(itemId);
    }

    private void verComanda() {
        verMesas();
        view.mostrarMensagem("Qual comanda quer ver?");
        int mesaId = scanner.nextInt() - 1;
        Mesa mesa = mesas[mesaId];
        mesa.getComanda().listarItens();
    }

    private void salvarGanhos() throws IOException {
        try (FileWriter writer = new FileWriter(CAMINHO_GANHOS)) {
            for (Map.Entry<LocalDate, Double> entry : ganhosDiarios.entrySet()) {
                writer.write(entry.getKey() + ":" + entry.getValue() + "\n");
            }
        }
    }

    private void carregarGanhos() throws IOException {
        ganhosDiarios.clear();
        try (Scanner scanner = new Scanner(new FileReader(CAMINHO_GANHOS))) {
            while (scanner.hasNextLine()) {
                String linha = scanner.nextLine();
                String[] partes = linha.split(":");
                if (partes.length == 2) {
                    try {
                        LocalDate data = LocalDate.parse(partes[0]);
                        Double ganho = Double.parseDouble(partes[1]);
                        ganhosDiarios.put(data, ganho);
                    } catch (Exception e) {
                        view.mostrarMensagem("Erro ao analisar a linha: " + linha);
                    }
                } else {
                    view.mostrarMensagem("Formato de linha inválido: " + linha);
                }
            }
        }
    }

    private void pesquisarLucroPorData() {
        view.mostrarMensagem("Digite a data para pesquisar os ganhos (AAAA-MM-DD):");
        String dataString = scanner.next();
        try {
            LocalDate data = LocalDate.parse(dataString);
            if (ganhosDiarios.containsKey(data)) {
                double ganhos = ganhosDiarios.get(data);
                view.mostrarMensagem("Ganhos para " + data + ": R$ " + ganhos);
            } else {
                view.mostrarMensagem("Nenhum ganho registrado para esta data.");
            }
        } catch (Exception e) {
            view.mostrarMensagem("Formato de data inválido.");
        }
    }
}
