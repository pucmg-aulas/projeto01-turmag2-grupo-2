package controller;

import model.ItemCardapio;

import java.util.ArrayList;

public class CardapioController {
    private ArrayList<ItemCardapio> itensCardapio;

    public CardapioController() {
        this.itensCardapio = new ArrayList<>();
    }

    public void adicionarAoCardapio(ItemCardapio item) {
        itensCardapio.add(item);
    }

    public boolean removerDoCardapio(int id) {
        return itensCardapio.removeIf(item -> item.getId() == id);
    }

    public ItemCardapio pedirItem(int id) {
        return itensCardapio.stream().filter(item -> item.getId() == id).findFirst().orElse(null);
    }

    public void listarCardapio() {
        itensCardapio.forEach(item -> System.out.println(item.getId() + ": " + item.getNome() + " - Preço: " + item.getPreco()));
    }

    public ArrayList<ItemCardapio> getItensCardapio() {
        return itensCardapio;
    }
}
