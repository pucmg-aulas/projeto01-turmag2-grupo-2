package controller;

import model.ItemCardapio;
import model.MetodoPagamento;

import java.util.ArrayList;

public class ComandaController {
    private ArrayList<ItemCardapio> itensComanda;
    private MetodoPagamento metodoPagamento;

    public ComandaController() {
        this.itensComanda = new ArrayList<>();
    }

    public void adicionarItem(ItemCardapio item) {
        itensComanda.add(item);
    }
    public void adicionarItem(ItemCardapio item,int quantidade) {
        for(int i = 0; i < quantidade; i++){
        itensComanda.add(item);
        }
    }

    public boolean removerItem(int id) {
        return itensComanda.removeIf(item -> item.getId() == id);
    }

    public ItemCardapio obterItem(int id) {
        return itensComanda.stream().filter(item -> item.getId() == id).findFirst().orElse(null);
    }

    public void listarItens() {
        itensComanda.forEach(item -> System.out.println(item));
    }

    public double calcularTotal() {
        double total = itensComanda.stream().mapToDouble(ItemCardapio::getPreco).sum();
        return total + total * 0.10; // Inclui a taxa de serviço de 10%
    }

    public double calcularDesconto() {
        double total = calcularTotal();
        return metodoPagamento.calcularDesconto(total);
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

    public ArrayList<ItemCardapio> getItensComanda() {
        return itensComanda;
    }
}
