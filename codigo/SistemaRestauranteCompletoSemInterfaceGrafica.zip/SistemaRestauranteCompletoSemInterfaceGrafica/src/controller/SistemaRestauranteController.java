package controller;

import model.*;
import view.SistemaRestauranteView;
import persistence.PedidosHistorico;
import persistence.LucrosPersistencia;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class SistemaRestauranteController {
    private SistemaRestauranteView view;
    private FilaDePedidosController filaController;
    private Mesa[] mesas;
    private CardapioController cardapioController;
    private ComandaController[] comandaControllers;
    private Scanner scanner;
    private PedidosHistorico historico;
    private LucrosPersistencia lucrosPersistencia;

    public SistemaRestauranteController(SistemaRestauranteView view) {
        this.view = view;
        this.filaController = new FilaDePedidosController();
        this.mesas = new Mesa[10];
        this.cardapioController = new CardapioController();
        this.comandaControllers = new ComandaController[10];
        this.scanner = new Scanner(System.in);
        this.historico = PedidosHistorico.getInstance();
        this.lucrosPersistencia = LucrosPersistencia.getInstance();
        preencherCardapio();
        quantificarMesas();
    }
    public SistemaRestauranteController( ) {
        this.filaController = new FilaDePedidosController();
        this.mesas = new Mesa[10];
        this.cardapioController = new CardapioController();
        this.comandaControllers = new ComandaController[10];
        this.scanner = new Scanner(System.in);
        this.historico = PedidosHistorico.getInstance();
        this.lucrosPersistencia = LucrosPersistencia.getInstance();
        preencherCardapio();
        quantificarMesas();
    }

    public void preencherCardapio() {
        cardapioController.adicionarAoCardapio(new ItemCardapio(1, "Moqueca de Tilápia", 50.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(2, "Falafel Assado", 30.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(3, "Salada Primavera com Macarrão Konjac", 40.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(4, "Escondidinho de Frango", 45.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(5, "Strogonoff", 30.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(6, "Caçarola de Carne com Legumes", 50.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(7, "Água", 5.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(8, "Suco", 8.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(9, "Refrigerante", 7.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(10, "Cerveja", 12.0));
        cardapioController.adicionarAoCardapio(new ItemCardapio(11, "Taça de Vinho", 18.0));
    }

    public void quantificarMesas() {
        for (int i = 0; i < 10; i++) {
            int capacidade = (i < 4) ? 4 : (i < 8) ? 6 : 8;
            mesas[i] = new Mesa(i + 1, capacidade, true);
            comandaControllers[i] = new ComandaController();
        }
    }


    public void iniciar() {
        view.mostrarMensagem("      *Bem Vindo!*      ");
        menu();
    }

    private void menu() {
        int escolha = 0;

        while (escolha != 10) {
            view.mostrarMenu();
            escolha = scanner.nextInt();

            try {
                switch (escolha) {
                    case 1:
                        view.mostrarMensagem(verMesas());
                        break;
                    case 2:
                        filaController.listarPedidos();
                        break;
                    case 3:
                        reservar();
                        break;
                    case 4:
                        remover();
                        break;
                    case 5:
                        view.mostrarMensagem(atenderPedido());
                        break;
                    case 6:
                        liberarMesa();
                        break;
                    case 7:
                        view.mostrarMensagem(listarHistorico());
                        break;
                    case 8:
                        menuServicos();
                        break;
                    case 9:
                        pesquisarLucroPorData();
                        break;
                    case 10:
                        view.mostrarMensagem("Volte sempre!");
                        break;
                    default:
                        view.mostrarMensagem("Escolha uma opção de 1 a 10!");
                        break;
                }
            } catch (Exception e) {
                view.mostrarMensagem("Ocorreu um erro: " + e.getMessage());
            }
        }
    }

    private void reservar() {
        try {
            view.mostrarMensagem("Nome do cliente:");
            String nome = scanner.next();

            view.mostrarMensagem("Telefone do cliente:");
            String telefone = scanner.next();

            Cliente cliente = new Cliente(nome, telefone);

            view.mostrarMensagem("Número de pessoas:");
            int numeroDePessoas = scanner.nextInt();

            Pedido pedido = new Pedido(cliente, numeroDePessoas, filaController.getFilaDeEspera().size());
            filaController.adicionarPedido(pedido);

            view.mostrarMensagem("Reserva realizada com sucesso!");
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao fazer a reserva: " + e.getMessage());
        }
    }

    public void fazerReserva(String nome, String telefone, int numeroDePessoas) {
        try {
            Cliente cliente = new Cliente(nome, telefone);
            Pedido pedido = new Pedido(cliente, numeroDePessoas, filaController.getFilaDeEspera().size());
            filaController.adicionarPedido(pedido);
            view.mostrarMensagem("Reserva realizada com sucesso!");
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao fazer a reserva: " + e.getMessage());
        }
    }

    private void remover() {
        try {
            view.mostrarMensagem("Qual o ID do pedido que deseja cancelar?");
            int id = scanner.nextInt();
            filaController.removerPedido(id);
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao remover a reserva: " + e.getMessage());
        }
    }

    public void cancelarReserva(int id) {
        try {
            filaController.removerPedido(id);
            view.mostrarMensagem("Reserva cancelada com sucesso!");
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao remover a reserva: " + e.getMessage());
        }
    }

    public String fecharComanda(int mesaId, String metodoPagamento) {
        try {
            Mesa mesa = mesas[mesaId - 1];
            MetodoPagamento metodo;

            switch (metodoPagamento.toLowerCase()) {
                case "dinheiro":
                    metodo = new Dinheiro();
                    break;
                case "pix":
                    metodo = new Pix();
                    break;
                case "débito":
                case "debito":
                    metodo = new Debito();
                    break;
                case "crédito":
                case "credito":
                    metodo = new Credito();
                    break;
                default:
                    return "Método de pagamento inválido.";
            }

            ComandaController comandaController = comandaControllers[mesaId - 1];
            comandaController.setMetodoPagamento(metodo);
            double totalAPagar = comandaController.calcularTotal();
            double valorPorPessoa = totalAPagar / mesa.getPedido().getNumeroDePessoas();
            double desconto = comandaController.calcularDesconto();
            double lucroRestaurante = totalAPagar - desconto;

            mesa.getPedido().registrarSaida();
            historico.addPedido(mesa.getPedido());
            mesa.desalocarMesa();

            LocalDate dataAtual = LocalDate.now();
            lucrosPersistencia.adicionarLucro(dataAtual, lucroRestaurante);

            return String.format("Total a Pagar: R$ %.2f\nValor por Pessoa: R$ %.2f\nLucro do Restaurante após desconto: R$ %.2f\nA mesa %d foi desocupada!",
                    totalAPagar, valorPorPessoa, lucroRestaurante, mesa.getIdMesa());
        } catch (Exception e) {
            return "Erro ao liberar a mesa: " + e.getMessage();
        }
    }

    public String listarHistorico() {
        StringBuilder sb = new StringBuilder();
        List<Pedido> pedidos = historico.getHistorico();
        if (pedidos.isEmpty()) {
            return "Nenhum histórico de pedidos.";
        }
        pedidos.forEach(pedido -> {
            sb.append("----------------------------------------------------------------------------------------------\n");
            sb.append("Cliente: ").append(pedido.getCliente().getNome())
                    .append(" | ID do pedido: ").append(pedido.getId())
                    .append(" | Número de Pessoas: ").append(pedido.getNumeroDePessoas())
                    .append(" | Tel. P/ contato: ").append(pedido.getCliente().getTelefone())
                    .append("\nEntrada: ").append(pedido.getEntrada())
                    .append(" | Saída: ").append(pedido.getSaida()).append("\n");
        });
        return sb.toString();
    }

    public String verFila() {
        StringBuilder sb = new StringBuilder();
        List<Pedido> filaDeEspera = filaController.getFilaDeEspera();
        if (filaDeEspera.isEmpty()) {
            return "A fila de espera está vazia.";
        }
        for (Pedido pedido : filaDeEspera) {
            sb.append("ID: ").append(pedido.getId())
                    .append(", Cliente: ").append(pedido.getCliente().getNome())
                    .append(", Número de Pessoas: ").append(pedido.getNumeroDePessoas())
                    .append("\n");
        }
        return sb.toString();
    }

    public String atenderPedido() {
        try {
            for (Mesa mesa : mesas) {
                if (mesa.isDisponibilidade()) {
                    Pedido pedido = filaController.proximoPedido(mesa.getCapacidade());
                    if (pedido != null) {
                        pedido.associarData();
                        mesa.alocarMesa(pedido);
                        filaController.removerPedido(pedido.getId());
                        return "O pedido com ID " + pedido.getId() + " foi alocado à mesa " + mesa.getIdMesa();
                    }
                }
            }
            return "Nenhum pedido disponível para alocar.";
        } catch (Exception e) {
            return "Erro ao atender o pedido: " + e.getMessage();
        }
    }

    private void liberarMesa() {
        try {
            verMesas();
            view.mostrarMensagem("Qual mesa deseja desocupar?");
            int mesaId = scanner.nextInt();
            Mesa mesa = mesas[mesaId - 1];

            view.mostrarMensagem("Escolha o método de pagamento: (1) Dinheiro (2) Pix (3) Débito (4) Crédito");
            int escolhaPagamento = scanner.nextInt();
            MetodoPagamento metodoPagamento;

            switch (escolhaPagamento) {
                case 1:
                    metodoPagamento = new Dinheiro();
                    break;
                case 2:
                    metodoPagamento = new Pix();
                    break;
                case 3:
                    metodoPagamento = new Debito();
                    break;
                case 4:
                    metodoPagamento = new Credito();
                    break;
                default:
                    view.mostrarMensagem("Método de pagamento inválido. Usando Dinheiro por padrão.");
                    metodoPagamento = new Dinheiro();
                    break;
            }

            ComandaController comandaController = comandaControllers[mesaId - 1];
            comandaController.setMetodoPagamento(metodoPagamento);
            double totalAPagar = comandaController.calcularTotal();
            double valorPorPessoa = totalAPagar / mesa.getPedido().getNumeroDePessoas();
            double desconto = comandaController.calcularDesconto();
            double lucroRestaurante = totalAPagar - desconto;

            view.mostrarMensagem("Total a Pagar: R$ " + totalAPagar);
            view.mostrarMensagem("Valor por Pessoa: R$ " + valorPorPessoa);
            view.mostrarMensagem("Lucro do Restaurante após desconto: R$ " + lucroRestaurante);

            mesa.getPedido().registrarSaida();
            historico.addPedido(mesa.getPedido());
            mesa.desalocarMesa();

            view.mostrarMensagem("A mesa " + mesa.getIdMesa() + " foi desocupada!");

            // Atualizar os ganhos do restaurante
            LocalDate dataAtual = LocalDate.now();
            lucrosPersistencia.adicionarLucro(dataAtual, lucroRestaurante);
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao liberar a mesa: " + e.getMessage());
        }
    }

    public String verMesas() {
        StringBuilder sb = new StringBuilder();
        sb.append("**********Mesas**********\n");
        for (Mesa mesa : mesas) {
            String disponibilidade = mesa.isDisponibilidade() ? "Disponível" : "Ocupada";
            sb.append("Mesa ").append(mesa.getIdMesa()).append(" Capacidade: ").append(mesa.getCapacidade()).append(" ").append(disponibilidade).append("\n");
            if (!mesa.isDisponibilidade()) {
                sb.append("Ocupada por: ").append(mesa.getPedido().getCliente().getNome()).append("\n");
            }
        }
        sb.append("*************************\n");
        return sb.toString();
    }

    public String pesquisarLucroPorData(String dataString) {
        try {
            LocalDate data = LocalDate.parse(dataString);
            Double ganhos = lucrosPersistencia.buscarLucroPorData(data);
            if (ganhos != null) {
                return "Ganhos para " + data + ": R$ " + ganhos;
            } else {
                return "Nenhum ganho registrado para esta data.";
            }
        } catch (Exception e) {
            return "Erro ao pesquisar ganhos: " + e.getMessage();
        }
    }

    private void menuServicos() {
        int escolhaMenu = 0;

        while (escolhaMenu != 6) {
            view.mostrarMenuServicos();
            escolhaMenu = scanner.nextInt();

            try {
                switch (escolhaMenu) {
                    case 1:
                        view.mostrarMensagem(verMesas());
                        break;
                    case 2:
                        cardapioController.listarCardapio();
                        break;
                    case 3:
                        fazerPedido();
                        break;
                    case 4:
                        cancelarPedido();
                        break;
                    case 5:
                        verComanda();
                        break;
                    case 6:
                        view.mostrarMensagem("Retornando ao menu principal...");
                        break;
                    default:
                        view.mostrarMensagem("Escolha uma opção de 1 a 6!");
                        break;
                }
            } catch (Exception e) {
                view.mostrarMensagem("Ocorreu um erro: " + e.getMessage());
            }
        }
    }

    private void fazerPedido() {
        try {
            verMesas();
            view.mostrarMensagem("Qual mesa fará o pedido?");
            int mesaId = scanner.nextInt() - 1;
            Mesa mesa = mesas[mesaId];
            ComandaController comandaController = comandaControllers[mesaId];

            while (true) {
                cardapioController.listarCardapio();
                view.mostrarMensagem("Digite o número do prato ou bebida que deseja ('0' PARA SAIR):");
                int itemId = scanner.nextInt();

                if (itemId == 0) {
                    break;
                }

                ItemCardapio item = cardapioController.pedirItem(itemId);
                if (item != null) {
                    view.mostrarMensagem("Digite a quantidade desejada:");
                    int quantidade = scanner.nextInt();
                    comandaController.adicionarItem(item, quantidade);
                } else {
                    view.mostrarMensagem("Item não encontrado!");
                }
            }
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao fazer o pedido: " + e.getMessage());
        }
    }

    private void cancelarPedido() {
        try {
            verMesas();
            view.mostrarMensagem("Qual mesa quer cancelar?");
            int mesaId = scanner.nextInt() - 1;
            Mesa mesa = mesas[mesaId];
            ComandaController comandaController = comandaControllers[mesaId];

            comandaController.listarItens();
            view.mostrarMensagem("Digite o número do prato ou bebida que deseja cancelar:");
            int itemId = scanner.nextInt();
            comandaController.removerItem(itemId);
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao cancelar o pedido: " + e.getMessage());
        }
    }

    private void verComanda() {
        try {
            verMesas();
            view.mostrarMensagem("Qual comanda quer ver?");
            int mesaId = scanner.nextInt() - 1;
            Mesa mesa = mesas[mesaId];
            ComandaController comandaController = comandaControllers[mesaId];
            comandaController.listarItens();
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao ver a comanda: " + e.getMessage());
        }
    }

    private void pesquisarLucroPorData() {
        try {
            view.mostrarMensagem("Digite a data para pesquisar os ganhos (AAAA-MM-DD):");
            String dataString = scanner.next();
            LocalDate data = LocalDate.parse(dataString);
            Double ganhos = lucrosPersistencia.buscarLucroPorData(data);
            if (ganhos != null) {
                view.mostrarMensagem("Ganhos para " + data + ": R$ " + ganhos);
            } else {
                view.mostrarMensagem("Nenhum ganho registrado para esta data.");
            }
        } catch (Exception e) {
            view.mostrarMensagem("Erro ao pesquisar ganhos: " + e.getMessage());
        }
    }

    public FilaDePedidosController getFilaController(){
        return filaController;
    }
    public LucrosPersistencia getLucrosPersistencia(){
        return lucrosPersistencia;
    }
}
