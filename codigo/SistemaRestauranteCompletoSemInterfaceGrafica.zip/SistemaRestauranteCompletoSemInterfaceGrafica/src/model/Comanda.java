package model;

import java.util.ArrayList;

public class Comanda {
    private ArrayList<ItemCardapio> itensComanda;
    private MetodoPagamento metodoPagamento;

    public Comanda() {
        this.itensComanda = new ArrayList<>();
    }

    public ArrayList<ItemCardapio> getItensComanda() {
        return itensComanda;
    }

    public void setItensComanda(ArrayList<ItemCardapio> itensComanda) {
        this.itensComanda = itensComanda;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }
}
