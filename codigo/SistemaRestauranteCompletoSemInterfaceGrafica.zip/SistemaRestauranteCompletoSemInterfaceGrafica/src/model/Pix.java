package model;

import java.time.LocalDate;

public class Pix implements MetodoPagamento {
    @Override
    public double calcularDesconto(double valor) {
        double desconto = valor * 0.0145;
        return Math.min(desconto, 10.0);
    }

    @Override
    public LocalDate obterDataRecebimento(LocalDate dataAtual) {
        return dataAtual;
    }
}

