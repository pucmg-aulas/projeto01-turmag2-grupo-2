package model;

import java.util.ArrayList;

public class FilaDePedidos {
    private ArrayList<Pedido> filaDeEspera;

    public FilaDePedidos() {
        filaDeEspera = new ArrayList<>();
    }

    public ArrayList<Pedido> getFilaDeEspera() {
        return filaDeEspera;
    }

    public void setFilaDeEspera(ArrayList<Pedido> filaDeEspera) {
        this.filaDeEspera = filaDeEspera;
    }
}
