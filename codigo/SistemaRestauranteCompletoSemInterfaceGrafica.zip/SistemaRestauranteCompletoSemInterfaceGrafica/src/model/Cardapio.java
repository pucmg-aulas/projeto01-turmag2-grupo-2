package model;

import java.util.ArrayList;

public class Cardapio {
    private ArrayList<ItemCardapio> itensCardapio;

    public Cardapio() {
        this.itensCardapio = new ArrayList<>();
    }

    public ArrayList<ItemCardapio> getItensCardapio() {
        return itensCardapio;
    }

    public void setItensCardapio(ArrayList<ItemCardapio> itensCardapio) {
        this.itensCardapio = itensCardapio;
    }
}
