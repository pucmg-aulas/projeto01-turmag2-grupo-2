package model;

import java.time.LocalDate;

public class Debito implements MetodoPagamento {
    @Override
    public double calcularDesconto(double valor) {
        return valor * 0.014;
    }

    @Override
    public LocalDate obterDataRecebimento(LocalDate dataAtual) {
        return dataAtual.plusDays(14);
    }
}

