package view;


public class SistemaRestauranteView {
    public void mostrarMensagem(String mensagem) {
        System.out.println(mensagem);
    }

    public void mostrarMenu() {
        System.out.println("***************Menu***************");
        System.out.println("*1- Ver Mesas                    *");
        System.out.println("*2- Ver Fila                     *");
        System.out.println("*3- Fazer Reserva                *");
        System.out.println("*4- Cancelar Reserva             *");
        System.out.println("*5- Atender Pedido               *");
        System.out.println("*6- Fechar comanda e Liberar Mesa*");
        System.out.println("*7- Histórico de Pedidos         *");
        System.out.println("*8- Setor de Serviços            *");
        System.out.println("*9- Pesquisar Ganhos por Data    *");
        System.out.println("*10- Sair                        *");
        System.out.println("**********************************");
    }

    public void mostrarMenuServicos() {
        System.out.println("**********Menu de Serviços**********");
        System.out.println("*1- Ver Mesas                      *");
        System.out.println("*2- Ver Cardápio                   *");
        System.out.println("*3- Fazer Pedido                   *");
        System.out.println("*4- Cancelar Pedido                *");
        System.out.println("*5- Ver Comanda                    *");
        System.out.println("*6- Sair                           *");
        System.out.println("************************************");
    }
}
