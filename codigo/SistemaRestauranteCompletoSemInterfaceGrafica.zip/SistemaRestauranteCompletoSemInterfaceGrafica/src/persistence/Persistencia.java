package persistence;

import java.io.*;
import java.time.LocalDate;
import java.util.Map;

public class Persistencia {
    public static void salvarObjeto(Object objeto, String caminho) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(caminho))) {
            oos.writeObject(objeto);
        }
    }

    public static Object carregarObjeto(String caminho) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(caminho))) {
            return ois.readObject();
        }
    }
    
    public static void salvarGanhos(Map<LocalDate, Double> ganhos, String caminho) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(caminho))) {
            oos.writeObject(ganhos);
        }
    }

   
    public static Map<LocalDate, Double> carregarGanhos(String caminho) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(caminho))) {
            return (Map<LocalDate, Double>) ois.readObject();
        }
    }
}
