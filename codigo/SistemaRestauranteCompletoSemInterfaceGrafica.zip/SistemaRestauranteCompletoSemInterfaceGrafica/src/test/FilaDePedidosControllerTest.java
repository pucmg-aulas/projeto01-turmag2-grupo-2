package test;

import model.Cliente;
import model.Pedido;
import controller.FilaDePedidosController;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FilaDePedidosControllerTest {
    private FilaDePedidosController filaDePedidosController;

    @Before
    public void setUp() {
        filaDePedidosController = new FilaDePedidosController();
    }

    @Test
    public void testAdicionarPedido() {
        Pedido pedido = new Pedido(new Cliente("João", "123456789"), 4, 1);
        filaDePedidosController.adicionarPedido(pedido);
        assertEquals(1, filaDePedidosController.getFilaDeEspera().size());
        assertEquals(pedido, filaDePedidosController.getFilaDeEspera().get(0));
    }

    @Test
    public void testRemoverPedido() {
        Pedido pedido1 = new Pedido(new Cliente("João", "123456789"), 4, 1);
        Pedido pedido2 = new Pedido(new Cliente("Maria", "987654321"), 2, 2);
        filaDePedidosController.adicionarPedido(pedido1);
        filaDePedidosController.adicionarPedido(pedido2);

        filaDePedidosController.removerPedido(1);
        assertEquals(1, filaDePedidosController.getFilaDeEspera().size());
        assertEquals(pedido2, filaDePedidosController.getFilaDeEspera().get(0));
    }

    @Test
    public void testProximoPedido() {
        Pedido pedido1 = new Pedido(new Cliente("João", "123456789"), 4, 1);
        Pedido pedido2 = new Pedido(new Cliente("Maria", "987654321"), 6, 2);
        filaDePedidosController.adicionarPedido(pedido1);
        filaDePedidosController.adicionarPedido(pedido2);

        Pedido proximo = filaDePedidosController.proximoPedido(5);
        assertEquals(pedido1, proximo);

        proximo = filaDePedidosController.proximoPedido(3);
        assertNull(proximo);
    }

    @Test
    public void testRetornaPedido() {
        Pedido pedido = new Pedido(new Cliente("João", "123456789"), 4, 1);
        filaDePedidosController.adicionarPedido(pedido);
        assertEquals(pedido, filaDePedidosController.retornaPedido(0));
    }

    @Test
    public void testListarPedidos() {
        Pedido pedido = new Pedido(new Cliente("João", "123456789"), 4, 1);
        filaDePedidosController.adicionarPedido(pedido);
        
        filaDePedidosController.listarPedidos();
    }

    @Test
    public void testListarHistorico() {
        Pedido pedido = new Pedido(new Cliente("João", "123456789"), 4, 1);
        pedido.associarData();
        pedido.registrarSaida();
        filaDePedidosController.adicionarPedido(pedido);
        
        filaDePedidosController.listarHistorico();
    }
}
