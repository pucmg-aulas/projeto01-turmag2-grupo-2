package test;

import model.ItemCardapio;
import model.MetodoPagamento;
import model.Dinheiro;
import controller.ComandaController;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ComandaControllerTest {
    private ComandaController comandaController;

    @Before
    public void setUp() {
        comandaController = new ComandaController();
        comandaController.setMetodoPagamento(new Dinheiro()); // Usando dinheiro para evitar desconto
    }

    @Test
    public void testAdicionarItem() {
        ItemCardapio item = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        comandaController.adicionarItem(item);
        assertEquals(1, comandaController.getItensComanda().size());
        assertEquals(item, comandaController.getItensComanda().get(0));
    }

    @Test
    public void testAdicionarItemQuantidade() {
        ItemCardapio item = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        comandaController.adicionarItem(item, 3);
        assertEquals(3, comandaController.getItensComanda().size());
        assertEquals(item, comandaController.getItensComanda().get(0));
        assertEquals(item, comandaController.getItensComanda().get(1));
        assertEquals(item, comandaController.getItensComanda().get(2));
    }

    @Test
    public void testRemoverItem() {
        ItemCardapio item1 = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        ItemCardapio item2 = new ItemCardapio(2, "Falafel Assado", 30.0);
        comandaController.adicionarItem(item1);
        comandaController.adicionarItem(item2);

        assertTrue(comandaController.removerItem(1));
        assertEquals(1, comandaController.getItensComanda().size());
        assertEquals(item2, comandaController.getItensComanda().get(0));
    }

    @Test
    public void testObterItem() {
        ItemCardapio item = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        comandaController.adicionarItem(item);
        assertEquals(item, comandaController.obterItem(1));
    }

    @Test
    public void testCalcularTotal() {
        ItemCardapio item1 = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        ItemCardapio item2 = new ItemCardapio(2, "Falafel Assado", 30.0);
        comandaController.adicionarItem(item1);
        comandaController.adicionarItem(item2);
        double total = (50.0 + 30.0) * 1.10; // 10% de taxa de serviço
        assertEquals(total, comandaController.calcularTotal(), 0.01);
    }

    @Test
    public void testCalcularDesconto() {
        ItemCardapio item1 = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        ItemCardapio item2 = new ItemCardapio(2, "Falafel Assado", 30.0);
        comandaController.adicionarItem(item1);
        comandaController.adicionarItem(item2);
        double total = (50.0 + 30.0) * 1.10; // 10% de taxa de serviço
        assertEquals(0, comandaController.calcularDesconto(), 0.01); // Sem desconto para dinheiro
    }

    @Test
    public void testSetMetodoPagamento() {
        MetodoPagamento metodoPagamento = new Dinheiro();
        comandaController.setMetodoPagamento(metodoPagamento);
        assertEquals(metodoPagamento, comandaController.getMetodoPagamento());
    }
}

