package test;
import controller.SistemaRestauranteController;
import model.Pedido;
import org.junit.Before;
import org.junit.Test;

import view.SistemaRestauranteView;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SistemaRestauranteControllerTest {
    private SistemaRestauranteController controller;
    private SistemaRestauranteView view;

    @Before
    public void setUp() {
        view = new SistemaRestauranteView();
        controller = new SistemaRestauranteController(view);
    }

    @Test
    public void testFazerReserva() {
        String nome = "João";
        String telefone = "123456789";
        int numeroDePessoas = 4;

        controller.fazerReserva(nome, telefone, numeroDePessoas);

        Pedido pedido = controller.getFilaController().getFilaDeEspera().get(0);
        assertEquals(nome, pedido.getCliente().getNome());
        assertEquals(telefone, pedido.getCliente().getTelefone());
        assertEquals(numeroDePessoas, pedido.getNumeroDePessoas());
    }

    @Test
    public void testCancelarReserva() {
        String nome = "João";
        String telefone = "123456789";
        int numeroDePessoas = 4;

        controller.fazerReserva(nome, telefone, numeroDePessoas);
        Pedido pedido = controller.getFilaController().getFilaDeEspera().get(0);
        controller.cancelarReserva(pedido.getId());

        assertTrue(controller.getFilaController().getFilaDeEspera().isEmpty());
    }

    @Test
    public void testFecharComanda() {
        String nome = "João";
        String telefone = "123456789";
        int numeroDePessoas = 4;
        String metodoPagamento = "dinheiro";

        controller.fazerReserva(nome, telefone, numeroDePessoas);
        controller.atenderPedido();

        String result = controller.fecharComanda(1, metodoPagamento);

        assertTrue(result.contains("Total a Pagar: R$"));
        assertTrue(result.contains("Valor por Pessoa: R$"));
        assertTrue(result.contains("Lucro do Restaurante após desconto: R$"));
    }

    @Test
    public void testVerMesas() {
        String result = controller.verMesas();
        assertTrue(result.contains("**********Mesas**********"));
        assertTrue(result.contains("Disponível"));
    }

    @Test
    public void testPesquisarLucroPorData() {
        LocalDate data = LocalDate.now();
        controller.getLucrosPersistencia().adicionarLucro(data, 100.0);

        String result = controller.pesquisarLucroPorData(data.toString());
        assertTrue(result.contains("Ganhos para " + data + ": R$ 100.0"));
    }

    @Test
    public void testAtenderPedido() {
        String nome = "João";
        String telefone = "123456789";
        int numeroDePessoas = 4;

        controller.fazerReserva(nome, telefone, numeroDePessoas);
        String result = controller.atenderPedido();

        assertTrue(result.contains("O pedido com ID"));
    }

   
}
