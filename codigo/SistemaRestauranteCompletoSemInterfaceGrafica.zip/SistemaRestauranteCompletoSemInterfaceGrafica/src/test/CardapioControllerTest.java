package test;

import model.ItemCardapio;
import controller.CardapioController;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CardapioControllerTest {
    private CardapioController cardapioController;

    @Before
    public void setUp() {
        cardapioController = new CardapioController();
    }

    @Test
    public void testAdicionarAoCardapio() {
        ItemCardapio item = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        cardapioController.adicionarAoCardapio(item);
        assertEquals(1, cardapioController.getItensCardapio().size());
        assertEquals(item, cardapioController.getItensCardapio().get(0));
    }

    @Test
    public void testRemoverDoCardapio() {
        ItemCardapio item1 = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        ItemCardapio item2 = new ItemCardapio(2, "Falafel Assado", 30.0);
        cardapioController.adicionarAoCardapio(item1);
        cardapioController.adicionarAoCardapio(item2);

        assertTrue(cardapioController.removerDoCardapio(1));
        assertEquals(1, cardapioController.getItensCardapio().size());
        assertEquals(item2, cardapioController.getItensCardapio().get(0));
    }

    @Test
    public void testPedirItem() {
        ItemCardapio item = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        cardapioController.adicionarAoCardapio(item);
        assertEquals(item, cardapioController.pedirItem(1));
    }

    @Test
    public void testListarCardapio() {
        ItemCardapio item1 = new ItemCardapio(1, "Moqueca de Tilápia", 50.0);
        ItemCardapio item2 = new ItemCardapio(2, "Falafel Assado", 30.0);
        cardapioController.adicionarAoCardapio(item1);
        cardapioController.adicionarAoCardapio(item2);
        
        // No assertion, just ensure no exceptions are thrown
        cardapioController.listarCardapio();
    }
}

