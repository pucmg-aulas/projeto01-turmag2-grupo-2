package controller;

import model.Pedido;

import java.util.ArrayList;

public class FilaDePedidosController {
    private ArrayList<Pedido> filaDeEspera;

    public FilaDePedidosController() {
        filaDeEspera = new ArrayList<>();
    }

    public void adicionarPedido(Pedido pedido) {
        filaDeEspera.add(pedido);
    }

    public void removerPedido(int id) {
        filaDeEspera.removeIf(p -> p.getId() == id);
    }

    public Pedido proximoPedido(int capacidade) {
        for (Pedido pedido : filaDeEspera) {
            if (pedido != null && pedido.getNumeroDePessoas() <= capacidade) {
                return pedido;
            }
        }
        return null;
    }

    public Pedido retornaPedido(int num) {
        return filaDeEspera.get(num);
    }

    public void listarPedidos() {
        for (Pedido pedido : filaDeEspera) {
            System.out.println("----------------------------------------------------------------------------------------------");
            System.out.println("Cliente: " + pedido.getCliente().getNome() + " ID do pedido: " + pedido.getId() + " Num de Pessoas: " + pedido.getNumeroDePessoas() + " Tel. P/ contato: " + pedido.getCliente().getTelefone());
            System.out.println("----------------------------------------------------------------------------------------------");
        }
    }

    public void listarHistorico() {
        for (Pedido pedido : filaDeEspera) {
            System.out.println("----------------------------------------------------------------------------------------------");
            System.out.println("Cliente: " + pedido.getCliente().getNome() + " ID do pedido: " + pedido.getId() + " Num de Pessoas: " + pedido.getNumeroDePessoas() + " Tel. P/ contato: " + pedido.getCliente().getTelefone());
            System.out.println("Entrada: " + pedido.getEntrada() + " Saida: " + pedido.getSaida());
            System.out.println("----------------------------------------------------------------------------------------------");
        }
    }

    public ArrayList<Pedido> getFilaDeEspera() {
        return filaDeEspera;
    }
}
