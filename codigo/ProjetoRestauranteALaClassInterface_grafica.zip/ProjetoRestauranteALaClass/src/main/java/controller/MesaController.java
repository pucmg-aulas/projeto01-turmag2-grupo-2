package controller;

import model.Mesa;
import view.MesaView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MesaController {
    private List<Mesa> mesas;
    private MesaView view;

    public MesaController(List<Mesa> mesas, MesaView view) {
        this.mesas = mesas;
        this.view = view;

        // Configuração dos botões na view
        this.view.getBtnAlocar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alocarMesa();
            }
        });

        this.view.getBtnDesalocar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                desalocarMesa();
            }
        });

        // Inicializa a view
        atualizarView();
    }

    private Mesa getMesaSelecionada() {
        int idMesaSelecionada = view.getMesaSelecionada();
        for (Mesa mesa : mesas) {
            if (mesa.getIdMesa() == idMesaSelecionada) {
                return mesa;
            }
        }
        return null;
    }

    public void alocarMesa() {
        Mesa mesa = getMesaSelecionada();
        if (mesa != null) {
            mesa.alocarMesa(); // Aqui você pode passar o ID do pedido se necessário
            atualizarView();
        }
    }

    public void desalocarMesa() {
        Mesa mesa = getMesaSelecionada();
        if (mesa != null) {
            mesa.desalocarMesa();
            atualizarView();
        }
    }

    public void atualizarView() {
        Mesa mesa = getMesaSelecionada();
        if (mesa != null) {
            view.setIdMesa(mesa.getIdMesa());
            view.setCapacidade(mesa.getCapacidade());
            view.setDisponibilidade(mesa.isDisponibilidade());
        }
    }

    public void mostrarMesaView() {
        view.setVisible(true);
    }
}
