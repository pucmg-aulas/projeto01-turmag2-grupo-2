package controller;

import model.Comanda;
import model.ItemCardapio;
import model.MetodoPagamento;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ComandaController {
    private Map<Integer, Comanda> comandas;
          private MetodoPagamento metodoPagamento;


    public ComandaController() {
        this.comandas = new HashMap<>();
    }

    public void criarComanda(int mesa) {
        comandas.put(mesa, new Comanda(mesa));
    }

    public void removerComanda(int mesa) {
        comandas.remove(mesa);
    }

    public void adicionarItem(int mesa, ItemCardapio item) {
        Comanda comanda = comandas.get(mesa);
        if (comanda != null) {
            comanda.getItensComanda().add(item);
        }
    }

    public boolean removerItem(int mesa, int id) {
        Comanda comanda = comandas.get(mesa);
        if (comanda != null) {
            return comanda.getItensComanda().removeIf(item -> item.getId() == id);
        }
        return false;
    }

    public Comanda obterComanda(int mesa) {
        return comandas.get(mesa);
    }

    public List<Comanda> obterTodasComandas() {
        return new ArrayList<>(comandas.values());
    }

    public double calcularTotal(int mesa) {
        Comanda comanda = comandas.get(mesa);
        if (comanda != null) {
            double total = comanda.getItensComanda().stream().mapToDouble(ItemCardapio::getPreco).sum();
            return total + total * 0.10; // Inclui a taxa de serviço de 10%
        }
        return 0;
    }

    public void setMetodoPagamento(int mesa, MetodoPagamento metodoPagamento) {
        Comanda comanda = comandas.get(mesa);
        if (comanda != null) {
            comanda.setMetodoPagamento(metodoPagamento);
        }
    }

    public MetodoPagamento getMetodoPagamento(int mesa) {
        Comanda comanda = comandas.get(mesa);
        if (comanda != null) {
            return comanda.getMetodoPagamento();
        }
        return null;
    }
    


public double calcularDesconto(int mesa) {
    double total = calcularTotal(mesa);
    if (comandas.containsKey(mesa)) {
        MetodoPagamento metodoPagamento = comandas.get(mesa).getMetodoPagamento();
        if (metodoPagamento != null) {
            return metodoPagamento.calcularDesconto(total);
        }
    }
    return 0;
}

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

}
