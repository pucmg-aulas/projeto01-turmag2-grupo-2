package controller;

import model.ItemCardapio;

import java.util.ArrayList;

public class CardapioController {
    private ArrayList<ItemCardapio> itensCardapio;

    public CardapioController() {
        this.itensCardapio = new ArrayList<>();
    }

    public void adicionarAoCardapio(ItemCardapio item) {
        itensCardapio.add(item);
    }

    public boolean removerDoCardapio(int id) {
        return itensCardapio.removeIf(item -> item.getId() == id);
    }

    public ItemCardapio obterItemCardapio(int id) {
        return itensCardapio.stream().filter(item -> item.getId() == id).findFirst().orElse(null);
    }

    public ArrayList<ItemCardapio> getItensCardapio() {
        return itensCardapio;
    }
}
