/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetorestaurantealaclass;


import controller.CardapioController;
import controller.ComandaController;
import controller.FilaDePedidosController;
import controller.MesaController;
import model.Comanda;
import model.Mesa;
import view.CardapioView;
import view.ComandaView;
import view.MesaView;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import model.ItemCardapio;
import view.PedidoFormView;

public class ProjetoRestauranteALaClass extends JFrame {

    private static ComandaController comandaController;
    private static CardapioController cardapioController;
    public static MesaController mesaController;
    private FilaDePedidosController filaController;
    private FilaDePedidosController historicoController;

    public ProjetoRestauranteALaClass(ComandaController comandaController, CardapioController cardapioController, List<Mesa> mesas) {
        this.comandaController = comandaController;
        this.cardapioController = cardapioController;
        this.mesaController = new MesaController(mesas, new MesaView(mesas)); // Passa a lista de mesas para o MesaController
        initialize();
    }

    private void initialize() {
        // Configurações do JFrame
        setTitle("Sistema de Gerenciamento");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new GridLayout(4, 2, 10, 10));

        JButton mesasButton = new JButton("Ver Mesas");
        mesasButton.addActionListener(e -> {
            // Chama o método mostrarMesaView da MesaController para exibir a MesaView
            mesaController.mostrarMesaView();
        });
        getContentPane().add(mesasButton);
        
         JButton btnverFila = new JButton("Ver Fila");
        btnverFila.addActionListener(e -> {
            new view.PedidoView().setVisible(true);
        });
        getContentPane().add(btnverFila);
        
         JButton btnfazerReserva = new JButton("Fazer Reserva");
        btnfazerReserva.addActionListener(e -> {
            new PedidoFormView().setVisible(true);
            // Listener vazio para o botão 1
        });
        getContentPane().add(btnfazerReserva);
        
         JButton btncancelarReserva = new JButton("Cancelar Reserva");
        btncancelarReserva.addActionListener(e -> {
            // Listener vazio para o botão 1
        });
        getContentPane().add(btncancelarReserva);

        JButton comandaButton = new JButton("Gerenciar Comandas");
        comandaButton.addActionListener(e -> SwingUtilities.invokeLater(() -> new ComandaView(comandaController, cardapioController).setVisible(true)));
        getContentPane().add(comandaButton);
        

        JButton cardapioButton = new JButton("Ver Cardápio");
        cardapioButton.addActionListener(e -> SwingUtilities.invokeLater(() -> new CardapioView(cardapioController).setVisible(true)));
        getContentPane().add(cardapioButton);

      
        
        

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ComandaController comandaController = new ComandaController();
            CardapioController cardapioController = new CardapioController();

            // Adicionando itens ao cardápio
            cardapioController.adicionarAoCardapio(new ItemCardapio(1, "Moqueca de Tilápia", 30.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(2, "Falafel Assado", 20.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(3, "Salada Primavera com Macarrão Konjac", 22.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(4, "Escondidinho de Frango", 28.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(5, "Strogonoff", 26.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(6, "Caçarola de carne com legumes", 32.0));

// Adicionando bebidas ao cardápio 
            cardapioController.adicionarAoCardapio(new ItemCardapio(7, "Água", 3.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(8, "Suco", 5.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(9, "Refrigerante", 5.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(10, "Cerveja", 8.0));
            cardapioController.adicionarAoCardapio(new ItemCardapio(11, "Taça de vinho", 12.0));

            // Inicialização das mesas
            List<Mesa> mesas = new ArrayList<>();
            for (int i = 1; i <= 4; i++) {
                mesas.add(new Mesa(i, 4, true)); // 4 mesas com capacidade 4
            }
            for (int i = 5; i <= 8; i++) {
                mesas.add(new Mesa(i, 6, true)); // 4 mesas com capacidade 6
            }
            for (int i = 9; i <= 10; i++) {
                mesas.add(new Mesa(i, 8, true)); // 2 mesas com capacidade 8
            }

            // Inicialização das comandas
            List<Comanda> comandas = new ArrayList<>();
            for (int i = 1; i <= 10; i++) {
                comandas.add(new Comanda(i));
            }

            new ProjetoRestauranteALaClass(comandaController, cardapioController, mesas).setVisible(true);
        });
    }
}
