package model;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import controller.ComandaController;
public class Pedido {

    private int id;
    private Cliente cliente;
    private int numeroDePessoas;
    private Comanda comanda;
    private String saida;
    private String entrada;
    private boolean statusPedido;
    private int mesa;
    private MetodoPagamento metodoPagamento;

    public Pedido(Cliente cliente, int numeroDePessoas, int id) {
        this.cliente = cliente;
        this.numeroDePessoas = numeroDePessoas;
        this.id = id;
        this.statusPedido = false;
        this.mesa = 0;
    }

    public Pedido() {
        
    }

    public void associarData() {
        this.statusPedido = true;
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        this.entrada = sdf.format(cal.getTime());
    }

    public void registrarSaida() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        this.saida = sdf.format(cal.getTime());
    }

  /*  public double valorDividido() {
        double valorTotal = comandaconmController.calcularTotal();
        return valorTotal / this.numeroDePessoas;
    }*/

    // Getters e Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getNumeroDePessoas() {
        return numeroDePessoas;
    }

    public void setNumeroDePessoas(int numeroDePessoas) {
        this.numeroDePessoas = numeroDePessoas;
    }

    public Comanda getComanda() {
        return comanda;
    }

    public void setComanda(Comanda comanda) {
        this.comanda = comanda;
    }

    public String getSaida() {
        return saida;
    }

    public void setSaida(String saida) {
        this.saida = saida;
    }

    public String getEntrada() {
        return entrada;
    }

    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }

    public boolean isStatusPedido() {
        return statusPedido;
    }

    public void setStatusPedido(boolean statusPedido) {
        this.statusPedido = statusPedido;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }
    
     @Override
    public String toString() {
        return "ID: " + id +
               "\nNúmero de Pessoas: " + numeroDePessoas +
               "\nComanda: " + comanda +
               "\nSaída: " + saida +
               "\nEntrada: " + entrada +
               "\nStatus do Pedido: " + (statusPedido ? "Atendido" : "Não atendido") +
               "\nMesa: " + mesa +
               "\nMétodo de Pagamento: " + metodoPagamento;
    }
}
