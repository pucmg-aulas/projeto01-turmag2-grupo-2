package model;

import java.util.ArrayList;

public class Comanda {
    private int mesa;
    private ArrayList<ItemCardapio> itensComanda;
    private double valotTotal;
    private MetodoPagamento metodoPagamento;

    public Comanda(int mesa) {
        this.mesa = mesa;
        this.itensComanda = new ArrayList<>();
    }

    public ArrayList<ItemCardapio> getItensComanda() {
        return itensComanda;
    }

    public void setItensComanda(ArrayList<ItemCardapio> itensComanda) {
        this.itensComanda = itensComanda;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }
}
