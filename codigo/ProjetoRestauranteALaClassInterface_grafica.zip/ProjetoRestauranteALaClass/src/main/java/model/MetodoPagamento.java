package model;

import java.time.LocalDate;

public interface MetodoPagamento {
    double calcularDesconto(double valor);
    LocalDate obterDataRecebimento(LocalDate dataAtual);
}

