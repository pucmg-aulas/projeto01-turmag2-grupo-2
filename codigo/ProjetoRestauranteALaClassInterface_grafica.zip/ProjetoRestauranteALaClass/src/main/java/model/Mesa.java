package model;

public class Mesa {
    private int idMesa;
    private int capacidade;
    private boolean disponibilidade;

    public Mesa(int idMesa, int capacidade, boolean disponibilidade) {
        this.idMesa = idMesa;
        this.capacidade = capacidade;
        this.disponibilidade = disponibilidade;
    }

    public int getIdMesa() {
        return idMesa;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public void alocarMesa() {
        this.disponibilidade = false;
    }

    public void desalocarMesa() {
        this.disponibilidade = true;
    }
}
