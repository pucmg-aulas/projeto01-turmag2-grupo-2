package persistence;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.io.IOException;

public class LucrosPersistencia extends AbstractDAO implements Serializable {
    private Map<LocalDate, Double> ganhosDiarios;
    private static LucrosPersistencia instance;
    private final String localArquivo = "./data/Lucros.txt";

    private LucrosPersistencia() {
        this.ganhosDiarios = new HashMap<>();
        try {
            carregaGanhos();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public static LucrosPersistencia getInstance() {
        if (instance == null) {
            instance = new LucrosPersistencia();
        }
        return instance;
    }

    public void adicionarLucro(LocalDate data, Double valor) {
        ganhosDiarios.put(data, valor);
        try {
            grava();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private void carregaGanhos() throws IOException {
        List<String> linhas = leituraTexto(localArquivo);
        ganhosDiarios = linhas.stream()
                .map(linha -> linha.split(":"))
                .filter(partes -> partes.length == 2)
                .collect(Collectors.toMap(
                        partes -> LocalDate.parse(partes[0]),
                        partes -> Double.parseDouble(partes[1])
                ));
    }

    private void grava() throws IOException {
        List<String> linhas = ganhosDiarios.entrySet().stream()
                .map(entry -> entry.getKey() + ":" + entry.getValue())
                .collect(Collectors.toList());
        gravaTexto(localArquivo, linhas);
    }

    public Map<LocalDate, Double> getGanhosDiarios() {
        return ganhosDiarios;
    }

    public Double buscarLucroPorData(LocalDate data) {
        return ganhosDiarios.get(data);
    }

    public void excluirLucro(LocalDate data) {
        ganhosDiarios.remove(data);
        try {
            grava();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
