package persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractDAO {

    protected void gravaTexto(String local, List<String> linhas) throws IOException {
        File file = new File(local);
        file.getParentFile().mkdirs(); // Cria os diretórios necessários

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String linha : linhas) {
                writer.write(linha);
                writer.newLine();
            }
            System.out.println("Dados gravados com sucesso");
        } catch (IOException e) {
            throw new IOException("Erro ao gravar: " + e.getMessage(), e);
        }
    }

    protected List<String> leituraTexto(String local) throws IOException {
        List<String> linhas = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(local))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                linhas.add(linha);
            }
        } catch (IOException e) {
            throw new IOException("Erro ao ler: " + e.getMessage(), e);
        }
        return linhas;
    }
}
