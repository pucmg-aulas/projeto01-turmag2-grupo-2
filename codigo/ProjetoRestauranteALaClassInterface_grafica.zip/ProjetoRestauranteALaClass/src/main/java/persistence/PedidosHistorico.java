package persistence;

import model.Pedido;
import model.Cliente;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.io.IOException;

public class PedidosHistorico extends AbstractDAO implements Serializable {
    private List<Pedido> historico;
    private static PedidosHistorico instance;
    private final String localArquivo = "./data/HistoricoPedidos.txt";

    private PedidosHistorico() {
        this.historico = new ArrayList<>();
        try {
            carregaHistorico();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public static PedidosHistorico getInstance() {
        if (instance == null) {
            instance = new PedidosHistorico();
        }
        return instance;
    }

    public void addPedido(Pedido pedido) {
        this.historico.add(pedido);
        try {
            grava();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private void carregaHistorico() throws IOException {
        List<String> linhas = leituraTexto(localArquivo);
        this.historico = linhas.stream()
                .map(linha -> {
                    String[] partes = linha.split(",");
                    if (partes.length == 6) {
                        Pedido pedido = new Pedido(
                                new Cliente(partes[1], partes[2]),
                                Integer.parseInt(partes[3]),
                                Integer.parseInt(partes[0])
                        );
                        pedido.setEntrada(partes[4]);
                        pedido.setSaida(partes[5]);
                        return pedido;
                    }
                    return null;
                })
                .collect(Collectors.toList());
    }

    private void grava() throws IOException {
        List<String> linhas = this.historico.stream()
                .map(pedido -> pedido.getId() + "," + pedido.getCliente().getNome() + "," + pedido.getCliente().getTelefone() + "," + pedido.getNumeroDePessoas() + "," + pedido.getEntrada() + "," + pedido.getSaida())
                .collect(Collectors.toList());
        gravaTexto(localArquivo, linhas);
    }

    public List<Pedido> getHistorico() {
        return historico;
    }

    public void excluirPedido(Pedido pedido) {
        historico.remove(pedido);
        try {
            grava();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public Pedido buscarPedidoPorId(int id) {
        return historico.stream()
                .filter(pedido -> pedido.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public boolean altera(Pedido pedidoExistente, int idAnterior) {
        try {
            historico = historico.stream()
                    .map(pedido -> pedido.getId() == idAnterior ? pedidoExistente : pedido)
                    .collect(Collectors.toList());
            grava();
            return true;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
}
