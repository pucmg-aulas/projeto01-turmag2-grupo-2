package view;

import com.mycompany.projetorestaurantealaclass.ProjetoRestauranteALaClass;
import controller.ComandaController;
import model.Comanda;
import model.ItemCardapio;

import javax.swing.*;
import java.awt.*;
import model.Credito;
import model.Debito;
import model.Dinheiro;
import model.Pix;

public class VisualizarComandaView extends JFrame {

    private ComandaController comandaController;
    private Comanda comanda;
    private JTextArea displayArea;
    double total;

    public VisualizarComandaView(ComandaController comandaController, Comanda comanda) {
        this.comandaController = comandaController;
        this.comanda = comanda;
        initialize();
        listarItens();
    }

    private void initialize() {
        setTitle("Visualizar Comanda - Mesa: " + comanda.getMesa());
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 2));

        JButton CreditoBtn = new JButton("Pagar no Crédito");
        panel.add(CreditoBtn);
        CreditoBtn.addActionListener(e -> PagarNoCredito());
        JButton DebitoBtn = new JButton("Pagar no Débito");
        panel.add(DebitoBtn);
        DebitoBtn.addActionListener(e -> PagarNoDebito());
        JButton MoneyBtn = new JButton("Pagar no Dinheiro");
        panel.add(MoneyBtn);
        MoneyBtn.addActionListener(e -> PagarNoDinheiro());
        JButton PixBtn = new JButton("Pagar no Pix");
        panel.add(PixBtn);
        PixBtn.addActionListener(e -> PagarNoPix());

        getContentPane().add(panel, BorderLayout.SOUTH);
    }

    private void listarItens() {
        displayArea.setText("");
        comanda.getItensComanda().forEach(item -> displayArea.append("ID: " + item.getId() + " - Nome: " + item.getNome() + " - Preço: " + item.getPreco() + "\n"));
        total = comandaController.calcularTotal(comanda.getMesa());
        String totalString = String.valueOf(total);

        displayArea.append("Total a pagar: " + totalString + "\n");

    }

    private void calcularTotal() {
        double total = comandaController.calcularTotal(comanda.getMesa());
        new PagamentoView(total).setVisible(true);
    }

    private void PagarNoCredito() {
        Credito metodoPagamento = new Credito();
        comandaController.setMetodoPagamento(metodoPagamento);
        double totalAPagar = total + metodoPagamento.calcularDesconto(total);
               JOptionPane.showMessageDialog(this, "Total Pago:" + String.valueOf(totalAPagar));
               OnFinish();
    }

    private void PagarNoDebito() {
        Debito metodoPagamento = new Debito();
        comandaController.setMetodoPagamento(metodoPagamento);
        double totalAPagar = total + metodoPagamento.calcularDesconto(total);
               JOptionPane.showMessageDialog(this, "Total Pago:" + String.valueOf(totalAPagar));
               OnFinish();
    }
    private void PagarNoDinheiro() {
        Dinheiro metodoPagamento = new Dinheiro();
        comandaController.setMetodoPagamento(metodoPagamento);
        double totalAPagar = total + metodoPagamento.calcularDesconto(total);
               JOptionPane.showMessageDialog(this, "Total Pago:" + String.valueOf(totalAPagar));
               OnFinish();
    }
    private void PagarNoPix() {
        Pix metodoPagamento = new Pix();
        comandaController.setMetodoPagamento(metodoPagamento);
        double totalAPagar = total + metodoPagamento.calcularDesconto(total);
               JOptionPane.showMessageDialog(this, "Total Pago:" + String.valueOf(totalAPagar));
               OnFinish();
    }
    
    private void OnFinish(){
       try {
            int mesa = comanda.getMesa();
            comandaController.removerComanda(mesa);
            JOptionPane.showMessageDialog(this, "Comanda removida com sucesso!");
           dispose();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Número da mesa inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
}
}
