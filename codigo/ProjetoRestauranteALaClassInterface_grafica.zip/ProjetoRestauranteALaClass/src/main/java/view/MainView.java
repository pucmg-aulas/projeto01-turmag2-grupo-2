package view;

import controller.CardapioController;
import controller.ComandaController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainView extends JFrame {
    private ComandaController comandaController;
    private CardapioController cardapioController;

    public MainView(ComandaController comandaController, CardapioController cardapioController) {
        this.comandaController = comandaController;
        this.cardapioController = cardapioController;
        initialize();
    }

    private void initialize() {
        // Configurações do JFrame
        setTitle("Sistema de Gerenciamento");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new GridLayout(3, 1));

        JButton comandaButton = new JButton("Gerenciar Comandas");
        comandaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new ComandaView(comandaController, cardapioController).setVisible(true));
            }
        });
        getContentPane().add(comandaButton);

        JButton cardapioButton = new JButton("Gerenciar Cardápio");
        cardapioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new CardapioView(cardapioController).setVisible(true));
            }
        });
        getContentPane().add(cardapioButton);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ComandaController comandaController = new ComandaController();
            CardapioController cardapioController = new CardapioController();
            new MainView(comandaController, cardapioController).setVisible(true);
        });
    }
}
