package view;

import controller.ComandaController;
import controller.CardapioController;
import model.Comanda;
import model.ItemCardapio;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ComandaView extends JFrame {
    private ComandaController comandaController;
    private CardapioController cardapioController;
    private JTextArea displayArea;
    private JTextField mesaField;
    private JTextField itemIdField;
    private JList<String> comandaList;

    public ComandaView(ComandaController comandaController, CardapioController cardapioController) {
        this.comandaController = comandaController;
        this.cardapioController = cardapioController;
        initialize();
    }

    private void initialize() {
        setTitle("Gerenciamento de Comandas");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());
                // Botão de fechar
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnFechar = new JButton("Fechar");
        btnFechar.addActionListener(e -> dispose());
        topPanel.add(btnFechar);
        getContentPane().add(topPanel, BorderLayout.NORTH);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 2));

        panel.add(new JLabel("Número da Mesa:"));
        mesaField = new JTextField();
        panel.add(mesaField);

        JButton criarComandaButton = new JButton("Criar Comanda");
        panel.add(criarComandaButton);
        criarComandaButton.addActionListener(e -> criarComanda());

        JButton removerComandaButton = new JButton("Remover Comanda");
        panel.add(removerComandaButton);
        removerComandaButton.addActionListener(e -> removerComanda());

        panel.add(new JLabel("ID do Item:"));
        itemIdField = new JTextField();
        panel.add(itemIdField);

        JButton adicionarItemButton = new JButton("Adicionar Item");
        panel.add(adicionarItemButton);
        adicionarItemButton.addActionListener(e -> adicionarItem());

        JButton removerItemButton = new JButton("Remover Item");
        panel.add(removerItemButton);
        removerItemButton.addActionListener(e -> removerItem());

        JButton listarItensButton = new JButton("Listar Itens");
        panel.add(listarItensButton);
        listarItensButton.addActionListener(e -> listarItens());

        JButton calcularTotalButton = new JButton("Calcular Total");
        panel.add(calcularTotalButton);
        calcularTotalButton.addActionListener(e -> calcularTotal());

        JButton exibirCardapioButton = new JButton("Exibir Cardápio");
        panel.add(exibirCardapioButton);
        exibirCardapioButton.addActionListener(e -> exibirCardapio());

        JButton visualizarComandaButton = new JButton("Visualizar Comanda");
        panel.add(visualizarComandaButton);
        visualizarComandaButton.addActionListener(e -> visualizarComanda());

      

        getContentPane().add(panel, BorderLayout.SOUTH);

        comandaList = new JList<>();
        JScrollPane comandaScrollPane = new JScrollPane(comandaList);
        getContentPane().add(comandaScrollPane, BorderLayout.WEST);

        atualizarListaComandas();
    }

    private void criarComanda() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            comandaController.criarComanda(mesa);
            JOptionPane.showMessageDialog(this, "Comanda criada com sucesso!");
            atualizarListaComandas();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Número da mesa inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

   public void removerComanda() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            comandaController.removerComanda(mesa);
            JOptionPane.showMessageDialog(this, "Comanda removida com sucesso!");
            atualizarListaComandas();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Número da mesa inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void adicionarItem() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            int id = Integer.parseInt(itemIdField.getText());

            ItemCardapio item = cardapioController.obterItemCardapio(id);
            if (item != null) {
                comandaController.adicionarItem(mesa, item);
                JOptionPane.showMessageDialog(this, "Item adicionado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Item não encontrado no cardápio.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Entrada inválida.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removerItem() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            int id = Integer.parseInt(itemIdField.getText());

            if (comandaController.removerItem(mesa, id)) {
                JOptionPane.showMessageDialog(this, "Item removido com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Item não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Entrada inválida.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listarItens() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            Comanda comanda = comandaController.obterComanda(mesa);
            if (comanda != null) {
                displayArea.setText("");
                comanda.getItensComanda().forEach(item -> displayArea.append("ID: " + item.getId() + " - Nome: " + item.getNome() + " - Preço: " + item.getPreco() + "\n"));
            } else {
                displayArea.setText("Comanda não encontrada.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Número da mesa inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void calcularTotal() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            double total = comandaController.calcularTotal(mesa);
            JOptionPane.showMessageDialog(this, String.format("Total da comanda: R$ %.2f", total));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Número da mesa inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exibirCardapio() {
        SwingUtilities.invokeLater(() -> new CardapioView(cardapioController).setVisible(true));
    }

    private void visualizarComanda() {
        try {
            int mesa = Integer.parseInt(mesaField.getText());
            Comanda comanda = comandaController.obterComanda(mesa);
            if (comanda != null) {
                SwingUtilities.invokeLater(() -> new VisualizarComandaView(comandaController, comanda).setVisible(true));
            } else {
                JOptionPane.showMessageDialog(this, "Comanda não encontrada.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Número da mesa inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarListaComandas() {
        List<Comanda> comandas = comandaController.obterTodasComandas();
        String[] comandaArray = comandas.stream().map(comanda -> "Mesa: " + comanda.getMesa()).toArray(String[]::new);
        comandaList.setListData(comandaArray);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ComandaController comandaController = new ComandaController();
            CardapioController cardapioController = new CardapioController();
            new ComandaView(comandaController, cardapioController).setVisible(true);
        });
    }
}
