package view;

import controller.CardapioController;
import model.ItemCardapio;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CardapioView extends JFrame {
    private CardapioController controller;
    private JTextArea displayArea;

    public CardapioView(CardapioController controller) {
        this.controller = controller;
        initialize();
        listarCardapio();
    }

    private void initialize() {
        // Configurações do JFrame
        setTitle("Cardápio");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());

        // Área de display para listar os itens do cardápio
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Botão de fechar
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnFechar = new JButton("Fechar");
        btnFechar.addActionListener(e -> dispose());
        topPanel.add(btnFechar);
        getContentPane().add(topPanel, BorderLayout.NORTH);
    }

    private void listarCardapio() {
        displayArea.setText("");
        List<ItemCardapio> itens = controller.getItensCardapio();
        for (ItemCardapio item : itens) {
            displayArea.append("ID: " + item.getId() + " - Nome: " + item.getNome() + " - Preço: " + item.getPreco() + "\n");
        }
    }

    public static void main(String[] args) {
        // Mock data for demonstration
        CardapioController controller = new CardapioController();
        controller.adicionarAoCardapio(new ItemCardapio(1, "Pizza", 25.0));
        controller.adicionarAoCardapio(new ItemCardapio(2, "Hamburger", 15.0));
        controller.adicionarAoCardapio(new ItemCardapio(3, "Refrigerante", 5.0));

        SwingUtilities.invokeLater(() -> new CardapioView(controller).setVisible(true));
    }
}
